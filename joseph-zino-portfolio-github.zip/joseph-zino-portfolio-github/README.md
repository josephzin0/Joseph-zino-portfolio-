# Joseph Zino portfolio

A plain static website: no build step, no framework.

- index.html   the whole site (HTML + CSS inline)
- assets/      logo, posters, motion video, favicons

## Publish with GitHub Pages
1. Create a free account at github.com and click New repository.
2. Name it josephzino-portfolio (or your-username.github.io for a shorter link). Set it to Public.
3. Click "uploading an existing file", drag in index.html and the assets folder, then Commit changes.
4. Go to Settings > Pages. Under Branch choose main and folder / (root), then Save.
5. After 1 to 2 minutes your link appears: https://your-username.github.io/josephzino-portfolio/

To update later: open the repo, Add file > Upload files, and replace index.html or add files to assets.
